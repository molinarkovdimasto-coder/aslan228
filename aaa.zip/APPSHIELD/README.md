JARVIS Power System - Termux Edition

This project contains:
- Android app (Compose) which connects to a Termux backend via HTTP (localhost:5000)
- Termux backend: Python Flask server that executes commands using Termux environment (psutil, subprocess)

Termux backend (server):
  - Save termux_backend/server.py in Termux (~/jarvis_backend/server.py)
  - Install dependencies: pip install flask psutil
  - Optional scripts in ~/jarvis_backend/scripts for vpn start/stop
  - Run: python ~/jarvis_backend/server.py

Build app in Termux:
  - Ensure Java is installed (pkg install openjdk-17)
  - Ensure gradle wrapper present or use installed gradle
  - chmod +x gradlew
  - ./gradlew assembleDebug
