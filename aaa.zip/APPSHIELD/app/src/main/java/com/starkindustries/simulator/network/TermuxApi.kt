package com.starkindustries.simulator.network

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody

object TermuxApi {
    private val client = OkHttpClient.Builder().build()
    private const val BASE = "http://127.0.0.1:5000"

    fun get(path: String): String {
        val req = Request.Builder().url(BASE + path).get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return "ERROR: ${'$'}{resp.code}"
            return resp.body?.string() ?: ""
        }
    }

    fun post(path: String, json: String): String {
        val media = "application/json; charset=utf-8".toMediaTypeOrNull()
        val req = Request.Builder().url(BASE + path).post(json.toRequestBody(media)).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return "ERROR: ${'$'}{resp.code}"
            return resp.body?.string() ?: ""
        }
    }
}
