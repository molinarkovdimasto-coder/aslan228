package com.starkindustries.simulator.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.starkindustries.simulator.ui.screens.*

@Composable
fun AppNavigation(navController: NavController) {
    NavHost(navController = navController, startDestination = "main") {
        composable("main") { MainScreen(navController) }
        composable("aim") { AimSimulationScreen(navController) }
        composable("movement") { MovementSimulationScreen(navController) }
        composable("strategy") { StrategySimulationScreen(navController) }
        composable("vpn") { VPNSimulationScreen(navController) }
        composable("stats") { StatsScreen(navController) }
    }
}
