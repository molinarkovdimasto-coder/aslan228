package com.starkindustries.simulator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.starkindustries.simulator.network.TermuxApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AimSimulationScreen(navController: NavController) {
    var host by remember { mutableStateOf("8.8.8.8") }
    var output by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Aim - Network Ping", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Host") })
        Button(onClick = {
            LaunchedEffect(host) {
                val res = withContext(Dispatchers.IO) { TermuxApi.get("/ping?host=${'$'}host") }
                output = res
            }
        }) { Text("Ping") }
        Text(output)
        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = { navController.popBackStack() }) { Text("Назад") }
    }
}
