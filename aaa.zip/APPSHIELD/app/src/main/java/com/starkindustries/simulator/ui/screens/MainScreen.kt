package com.starkindustries.simulator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.starkindustries.simulator.network.TermuxApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MainScreen(navController: NavController) {
    var stats by remember { mutableStateOf("No data") }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("JARVIS Power System", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = {
            LaunchedEffect(Unit) {
                val res = withContext(Dispatchers.IO) { TermuxApi.get("/stats") }
                stats = res
            }
        }) { Text("Refresh System Stats") }
        Text(stats)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { navController.navigate("aim") }) { Text("Aim") }
            Button(onClick = { navController.navigate("movement") }) { Text("Movement") }
            Button(onClick = { navController.navigate("strategy") }) { Text("Strategy") }
            Button(onClick = { navController.navigate("vpn") }) { Text("VPN") }
            Button(onClick = { navController.navigate("stats") }) { Text("Stats") }
        }
    }
}
