package com.starkindustries.simulator.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.starkindustries.simulator.network.TermuxApi
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MovementSimulationScreen(navController: NavController) {
    var latencies by remember { mutableStateOf(listOf<Int>()) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Movement - Ping Trace", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = {
            LaunchedEffect(Unit) {
                val res = withContext(Dispatchers.IO) { TermuxApi.get("/ping?host=8.8.8.8&count=5") }
                latencies = res.split("\n").mapNotNull { it.trim().toIntOrNull() }
            }
        }) { Text("Trace 5") }
        Box(modifier = Modifier.fillMaxWidth().height(240.dp)) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width/2, size.height/2)
                val maxR = size.minDimension/3
                latencies.forEachIndexed { idx, v ->
                    val angle = idx * 2.0 * Math.PI / maxOf(1, latencies.size)
                    val r = maxR * (v / 200f).coerceIn(0f,1f)
                    val x = center.x + (r * cos(angle)).toFloat()
                    val y = center.y + (r * sin(angle)).toFloat()
                    drawCircle(color = MaterialTheme.colorScheme.primary, radius = 10f, center = Offset(x,y))
                }
            }
        }
        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = { navController.popBackStack() }) { Text("Назад") }
    }
}
