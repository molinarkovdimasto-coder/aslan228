package com.starkindustries.simulator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.starkindustries.simulator.network.TermuxApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun StatsScreen(navController: NavController) {
    var output by remember { mutableStateOf("No data") }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Stats", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = {
            LaunchedEffect(Unit) {
                val res = withContext(Dispatchers.IO) { TermuxApi.get("/stats") }
                output = res
            }
        }) { Text("Get Stats") }
        Text(output)
        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = { navController.popBackStack() }) { Text("Назад") }
    }
}
