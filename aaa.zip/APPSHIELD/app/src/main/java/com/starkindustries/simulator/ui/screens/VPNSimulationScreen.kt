package com.starkindustries.simulator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.starkindustries.simulator.network.TermuxApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun VPNSimulationScreen(navController: NavController) {
    var status by remember { mutableStateOf("Unknown") }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("VPN Control", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = {
            LaunchedEffect(Unit) {
                val res = withContext(Dispatchers.IO) { TermuxApi.get("/vpn/start") }
                status = res
            }
        }) { Text("Start VPN (Termux script)") }
        Button(onClick = {
            LaunchedEffect(Unit) {
                val res = withContext(Dispatchers.IO) { TermuxApi.get("/vpn/stop") }
                status = res
            }
        }) { Text("Stop VPN") }
        Text("Status: ${'$'}status")
        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = { navController.popBackStack() }) { Text("Назад") }
    }
}
