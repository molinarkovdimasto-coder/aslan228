package com.starkindustries.simulator.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StarkDarkColors = darkColorScheme(
    primary = Color(0xFF00B0FF),
    onPrimary = Color.Black,
    background = Color(0xFF071126),
    surface = Color(0xFF0B1724),
    onSurface = Color(0xFFE6F7FF)
)

private val RedMagicDark = darkColorScheme(
    primary = Color(0xFFFF3B30),
    onPrimary = Color.Black,
    background = Color(0xFF0B0B0C),
    surface = Color(0xFF121212),
    onSurface = Color(0xFFFFEFEF)
)

enum class ThemeMode { STARK, REDMAGIC }

@Composable
fun StarkTheme(mode: ThemeMode = ThemeMode.STARK, content: @Composable () -> Unit) {
    val colors = when(mode) {
        ThemeMode.STARK -> StarkDarkColors
        ThemeMode.REDMAGIC -> RedMagicDark
    }
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
