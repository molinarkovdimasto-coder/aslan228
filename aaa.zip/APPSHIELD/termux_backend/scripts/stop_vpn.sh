#!/bin/sh
echo 'vpn stopped (placeholder)'
