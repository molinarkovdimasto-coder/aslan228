#!/usr/bin/env python3
from flask import Flask, request, jsonify
import psutil, subprocess, shlex, os
app = Flask('jarvis_backend')

@app.route('/stats')
def stats():
    cpu = psutil.cpu_percent(interval=0.5)
    mem = psutil.virtual_memory().percent
    try:
        load = os.getloadavg()
    except:
        load = (0,0,0)
    return jsonify({'cpu': cpu, 'memory': mem, 'load': load})

@app.route('/ping')
def ping():
    host = request.args.get('host','8.8.8.8')
    count = int(request.args.get('count','4'))
    cmd = f'ping -c {count} {shlex.quote(host)}'
    try:
        proc = subprocess.run(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=20)
        out = proc.stdout.decode(errors='ignore')
        times = []
        for line in out.splitlines():
            if 'time=' in line:
                try:
                    t = line.split('time=')[-1].split()[0].replace('ms','')
                    times.append(int(float(t)))
                except:
                    pass
        if times:
            return '\n'.join(str(x) for x in times)
        return out
    except Exception as e:
        return str(e), 500

@app.route('/vpn/<action>')
def vpn(action):
    home = os.path.expanduser('~')
    scripts = {
        'start': os.path.join(home, 'jarvis_backend', 'scripts', 'start_vpn.sh'),
        'stop': os.path.join(home, 'jarvis_backend', 'scripts', 'stop_vpn.sh')
    }
    path = scripts.get(action)
    if path and os.path.exists(path):
        try:
            proc = subprocess.run(['sh', path], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
            return proc.stdout.decode()
        except Exception as e:
            return str(e), 500
    return f'No script for {action}', 404

@app.route('/action', methods=['POST'])
def action():
    data = request.get_json() or {}
    cmd = data.get('cmd')
    if cmd == 'clear_cache':
        home = os.path.expanduser('~')
        cache_dir = os.path.join(home, '.cache')
        try:
            subprocess.run(['rm', '-rf', cache_dir])
            return 'Cache cleared'
        except Exception as e:
            return str(e), 500
    return jsonify({'ok': False, 'cmd': cmd})

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000)
